__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/480cae88cb118623.js",
  "static/chunks/turbopack-6e1961d2628bea24.js"
])
