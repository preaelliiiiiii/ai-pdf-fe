var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/route.js")
R.c("server/chunks/[root-of-the-server]__3bad9c85._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(23219)
R.m(55739)
module.exports=R.m(55739).exports
