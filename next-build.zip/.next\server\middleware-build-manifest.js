globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/480cae88cb118623.js",
      "static/chunks/turbopack-6e1961d2628bea24.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/480cae88cb118623.js",
      "static/chunks/turbopack-c41dffacfcfedb87.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/20ba8cffd2948dcc.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/2468949c4832742b.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/8de370c3cbabf345.js",
    "static/chunks/turbopack-ee6c98bbdb0b0ea9.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];